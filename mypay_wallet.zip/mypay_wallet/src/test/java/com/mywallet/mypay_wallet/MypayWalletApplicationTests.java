package com.mywallet.mypay_wallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MypayWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
