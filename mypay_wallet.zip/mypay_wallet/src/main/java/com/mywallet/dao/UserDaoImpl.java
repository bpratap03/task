package com.mywallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.mywallet.domain.EndUser;

@Repository
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void creatUser(EndUser user) {
	
		entityManager.persist(user);
	}

	@Override
	public List<EndUser> getAllUser() {
		return null;
	}

	@Override
	public EndUser getUserById(Integer id) {
		
		return  entityManager.find(EndUser.class, id);
	}

	@Override
	public void updateEnduser(EndUser user) {
	}

	@Override
	public void deleteUser(Integer id) {
	}

}
