package com.mywallet.dao;

import java.util.List;

import com.mywallet.domain.EndUser;

public interface IUserDao {

	public void creatUser(EndUser user);

	public List<EndUser> getAllUser();

	public EndUser getUserById(Integer id);

	public void updateEnduser(EndUser user);

	public void deleteUser(Integer id);
}
