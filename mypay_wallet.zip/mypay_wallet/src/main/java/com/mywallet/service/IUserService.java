package com.mywallet.service;

import java.util.List;

import com.mywallet.domain.EndUser;

public interface IUserService {
	
	public void creatUser(EndUser user);
	
	public List<EndUser> getAllUser();
	
	public EndUser getUserById(Integer id);
	
	public void updateEnduser(EndUser user);
	
	public void deleteUser(Integer id);

}
