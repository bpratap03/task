package com.mywallet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mywallet.dao.IUserDao;
import com.mywallet.domain.EndUser;

@Service
public class EndUserServiceImpl implements IUserService {

	@Autowired
	private IUserDao userDao ;

	@Override
	public void creatUser(EndUser user) {

		userDao.creatUser(user);
	}

	@Override
	public List<EndUser> getAllUser() {

		return userDao.getAllUser();
	}

	@Override
	public EndUser getUserById(Integer id) {

		return userDao.getUserById(id);
	}

	@Override
	public void updateEnduser(EndUser user) {

		userDao.updateEnduser(user);
	}

	@Override
	public void deleteUser(Integer id) {
		userDao.deleteUser(id);

	}

}
