/**
 * 
 */
package com.mywallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mywallet.domain.EndUser;
import com.mywallet.service.IUserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserService userService;

	@GetMapping("{id}")
	public ResponseEntity<?> getUserById(@PathVariable("id") int id) {

		return new ResponseEntity<EndUser>(userService.getUserById(id), HttpStatus.OK);
	}

	@PostMapping("/sign-up")
	public ResponseEntity<?> createUser(@RequestBody EndUser user) {

		userService.creatUser(user);

		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
}