package com.mywallet.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "enduser")
public class EndUser {

	@Id
	@Column(name = "user_id")
	private Integer userid;

	@Column(name = "lastname")
	private String laStName;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "mobile_no")
	private String mobileNumber;

	@Column(name = "password")
	private String password;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getLaStName() {
		return laStName;
	}

	public void setLaStName(String laStName) {
		this.laStName = laStName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
