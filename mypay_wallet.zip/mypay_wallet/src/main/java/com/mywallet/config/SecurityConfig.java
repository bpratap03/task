package com.mywallet.config;

public class SecurityConfig {

}
